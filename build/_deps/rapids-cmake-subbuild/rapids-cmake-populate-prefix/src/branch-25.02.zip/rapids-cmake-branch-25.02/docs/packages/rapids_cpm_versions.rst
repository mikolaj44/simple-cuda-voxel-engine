:orphan:

.. _cpm_version_format:

rapids-cmake package versions
#############################


.. _cpm_versions:
.. literalinclude:: /../rapids-cmake/cpm/versions.json
    :language: json
