.. cmake-module:: ../../rapids-cmake/cython-core/init.cmake
