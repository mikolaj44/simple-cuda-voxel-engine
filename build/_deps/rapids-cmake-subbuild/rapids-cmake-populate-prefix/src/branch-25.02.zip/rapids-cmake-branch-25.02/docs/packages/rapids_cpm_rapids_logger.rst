.. cmake-module:: ../../rapids-cmake/cpm/rapids_logger.cmake
