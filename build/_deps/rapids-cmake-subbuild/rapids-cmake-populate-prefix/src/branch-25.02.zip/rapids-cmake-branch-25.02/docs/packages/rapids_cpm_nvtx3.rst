.. cmake-module:: ../../rapids-cmake/cpm/nvtx3.cmake
