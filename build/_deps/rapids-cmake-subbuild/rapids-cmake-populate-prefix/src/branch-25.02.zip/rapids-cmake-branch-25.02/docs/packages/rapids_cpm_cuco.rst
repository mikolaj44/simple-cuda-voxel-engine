.. cmake-module:: ../../rapids-cmake/cpm/cuco.cmake
