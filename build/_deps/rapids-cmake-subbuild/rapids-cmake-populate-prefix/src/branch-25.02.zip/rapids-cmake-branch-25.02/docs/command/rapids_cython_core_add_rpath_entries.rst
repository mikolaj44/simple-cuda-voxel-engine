.. cmake-module:: ../../rapids-cmake/cython-core/add_rpath_entries.cmake
