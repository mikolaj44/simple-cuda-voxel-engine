.. cmake-module:: ../../rapids-cmake/cmake/download_with_retry.cmake
