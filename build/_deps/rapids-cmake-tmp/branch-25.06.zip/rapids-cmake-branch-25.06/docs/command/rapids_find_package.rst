.. cmake-module:: ../../rapids-cmake/find/package.cmake
