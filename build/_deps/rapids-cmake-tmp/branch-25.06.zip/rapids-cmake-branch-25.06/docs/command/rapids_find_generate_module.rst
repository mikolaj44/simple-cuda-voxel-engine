.. cmake-module:: ../../rapids-cmake/find/generate_module.cmake
